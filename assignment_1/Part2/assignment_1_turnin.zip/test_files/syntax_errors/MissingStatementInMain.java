public class MissingStatementInMain {
    public static void main(String[] a) {
    }// @error - syntax (missing statement)
}
